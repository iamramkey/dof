-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2015 at 08:02 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `d`
--

-- --------------------------------------------------------

--
-- Table structure for table `hpsm_tickets`
--

CREATE TABLE IF NOT EXISTS `hpsm_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_no` int(11) DEFAULT NULL,
  `si_no` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `case_no` varchar(255) DEFAULT NULL,
  `title` varchar(1000) DEFAULT NULL,
  `locations` varchar(255) DEFAULT NULL,
  `attack` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `engineer` varchar(255) DEFAULT NULL,
  `pending` varchar(255) DEFAULT NULL,
  `statuses` varchar(255) DEFAULT NULL,
  `closed` varchar(255) DEFAULT NULL,
  `comments` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `hpsm_tickets`
--

INSERT INTO `hpsm_tickets` (`id`, `id_no`, `si_no`, `created_date`, `case_no`, `title`, `locations`, `attack`, `priority`, `engineer`, `pending`, `statuses`, `closed`, `comments`) VALUES
(1, 535, 156, '2015-03-24 00:00:00', 'SD301609', 'SMB Fragment Packet Found', 'KPDC', 'Device Warning', 'Average', 'Prasanna', 'Sirt Team', 'Follow up', NULL, 'worngly assignd to time attendance.'),
(2, 580, 43, '2015-04-22 00:00:00', 'SD309441', 'WordPress Cuckootap Theme Arbitrary File Download Vulnerability', 'DOF_HQ', 'Application Vulnerability', 'Average', 'Karthi', 'Database Team', 'Follow up', NULL, 'kindly suggest.'),
(3, 591, 55, '2015-04-27 00:00:00', 'SD310752', 'High risk- endpoint - 10.25.158.129.', 'DOF_HQ', 'Exploit', 'Average', 'Prasanna', 'Sirt Team', 'Follow up', NULL, 'open with security team'),
(4, 598, 62, '2015-04-28 00:00:00', 'SD311293', 'SEPM Client Installation on DOFIT21485PC', 'DOF_HQ', 'Antivirus', 'Low', 'Karthi', 'SOC Team', 'Follow up', NULL, 'Unable to Push SEPM, Since the server is in Ofline'),
(5, 601, 65, '2015-04-29 00:00:00', 'SD311342', 'FRU Power Supply is not responding from the device address : 172.23.113.5', 'DOF_HQ', 'Device Warning', 'Average', 'Machamma', 'Network Team', 'Follow up', NULL, 'work in progress with dof-noc'),
(6, 605, 69, '2015-04-30 00:00:00', 'SD311904', 'Windows Reboot - HV-P-HQ-01.dof.abudhabi.gov', 'DOF_HQ', 'Device Warning', 'Average', 'Machamma', 'SYSTEM Admin', 'Follow up', NULL, 'Mail notification has been sent'),
(7, 607, 71, '2015-04-30 00:00:00', 'SD312097', 'Windows Reboot - finav01.dof.abudhabi.gov', 'DOF_HQ', 'Device Warning', 'Average', 'Machamma', 'SYSTEM Admin', 'Follow up', NULL, 'Mail notification has been sent'),
(8, 609, 73, '2015-04-30 00:00:00', 'SD312154', 'Windows: Shutdown - Reboot on 172.25.50.89 (epo-v-hq-01.dof.abudhabi.gov)', 'DOF_HQ', 'Device Warning', 'Average', 'Karthi', 'SYSTEM Admin', 'Follow up', NULL, 'Mail notification has been sent'),
(9, 610, 74, '2015-04-30 00:00:00', 'SD312155', 'Windows: Shutdown - Reboot on 172.25.50.111 (FinHVhost04.dof.abudhabi.gov)', 'DOF_HQ', 'Device Warning', 'Average', 'Karthi', 'SYSTEM Admin', 'Follow up', NULL, 'Mail notification has been sent'),
(10, 611, 75, '2015-05-01 00:00:00', 'SD312227', 'McAfee ESM connectivity Failure', 'DOF_HQ', 'Device Warning', 'Average', 'Karthi', 'SOC Team', 'Closed', 'kaleem', 'solved successfully'),
(11, 612, 76, '2015-05-03 00:00:00', 'SD312530', 'SD312530 -ephone:IP:socket:device Type:has unregistered abnormally', 'DOF_HQ', 'Device Warning', 'Low', 'kaleem', 'Network Team', 'Follow up', NULL, 'Mail notification has been sent'),
(12, 613, 77, '2015-05-04 00:00:00', 'SD312824', 'DOF HQ Users access Mina Proxy', 'DOF_HQ', 'Proxy', 'Average', 'kaleem', 'Sirt Team', 'Follow up', NULL, 'Mail notification has been sent'),
(13, 614, 78, '2015-05-04 00:00:00', 'SD312834', 'Kindly check connection 172.16.203.95', 'DOF_HQ', 'Network', 'Average', 'kaleem', 'Network Team', 'Follow up', NULL, 'Mail notification has been sent'),
(14, 615, 79, '2015-05-04 00:00:00', 'SD312792', 'A member was removed from a security-enabled global group', 'DOF_HQ', 'Device Warning', 'Average', 'kaleem', 'SYSTEM Admin', 'Closed', 'system team', 'Legitimate activity'),
(15, 616, 80, '2015-05-04 00:00:00', 'SD312898', 'Not receiving any proxy logs on ESM', 'DOF_HQ', 'Device Warning', 'low', 'kaleem', 'SOC Team', 'Follow up', NULL, 'Mail notification has been sent');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_name` (`location_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `location_name`) VALUES
(3, 'ADAC'),
(1, 'DOF_DR'),
(2, 'DOF_HQ'),
(7, 'KPDC'),
(6, 'Mezyad'),
(5, 'Mina'),
(4, 'Sila');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_id`, `status_name`) VALUES
(1, 'Follow up'),
(2, 'Closed');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
