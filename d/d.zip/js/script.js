(function () {
    angular.module("data_filter", []).controller("appController", ["$scope", "$http", '$sce', function appController($scope, $http, $sce) {
        $scope.getdata = db;
        $scope.list = db;
        $scope.search = '';
        $scope.add = false;
        $scope.createdDate = new Date().toLocaleDateString();
        $scope.format = function (value) {
            if (value) {
                if ($scope.search.trim().length > 0) {
                    var re = new RegExp($scope.search.trim(), 'i');
                    return $sce.trustAsHtml(value.replace(re, '<strong>$&</strong>'));
                }
                return $sce.trustAsHtml(value);
            }
            return $sce.trustAsHtml(value);
        };
        $scope.checkDisabled = function (key, value) {
            if (key == 'created_date') {
                return true;
            }
            return false;
        }
        document.getElementById('dataScript').parentNode.removeChild(document.getElementById('dataScript'));
        }]);
})();