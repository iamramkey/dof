<?php

// Kickstart the framework
$f3=require('lib/base.php');

$f3->set('DEBUG',1);
if ((float)PCRE_VERSION<7.9)
	trigger_error('PCRE version is out of date');

// Load configuration
$f3->config('config.ini');

function db(){
    return new DB\SQL(
        'mysql:host=localhost;port=3306;dbname=d',
        'root',
        ''
    );
}

$f3->route('GET /',function($f3){
    $db = db();
    $data = $db->exec('SELECT `id_no`, `si_no`, `created_date`, `case_no`, `title`, `locations`, `attack`, `priority`, `engineer`, `pending`, `statuses`, `closed`, `comments` FROM `hpsm_tickets`');
    $f3->set('db',$data);
    echo View::instance()->render('data_filter.html');
});

$f3->run();