
google.load("visualization", "1.1", {packages:["calendar"]});
google.setOnLoadCallback(drawChart);

var chartOptions,
    virusChart,
    virusData = {},
    virusDataTable;
function parser(data) {
    var rex = /(\<(\/)?[A-Za-z0-9]+\>)(\s)+/gi;
    data = data.replace(rex, "$1");
    return $.parseXML(data);
}
function hasResponses(datasource) {
    return datasource.length - 1;
}
Date.prototype.yyyymmdd = function() {
    var yyyy = this.getFullYear().toString();
    var mm = (this.getMonth()+1).toString(); // getMonth() is zero-based
    var dd  = this.getDate().toString();
    return yyyy + '-' + (mm[1]?mm:"0"+mm[0]) + '-' + (dd[1]?dd:"0"+dd[0]); // padding
};

function virusReady(){
    console.log($('#chart1 text:contains(Jan)'));
    google.visualization.events.addListener(virusChart, 'select', virusHandler);
}
function virusHandler(e) {
    if(virusData[new Date(virusChart.getSelection()[0].date).toISOString().substring(0, 10)]){
        $('.modal-title').text('Virus Attacks');
        $('#table').fadeIn();
        $('#tableHead').html('')
            .append($('<th>').text('IPAddress'))
            .append($('<th>').text('LOCATION'))
            .append($('<th>').text('ACTION'))
            .append($('<th>').text('TIMESTAMP'))
            .append($('<th>').text('Hostname'));
        $('#tableBody').html('');
        for(var i = 0 ;each = virusData[new Date(virusChart.getSelection()[0].date).yyyymmdd()][i] ; i++){
            var tr = $('<tr>');
            $('#tableBody').append(tr);
            tr.append($('<td>').text(each['ipaddress']))
            tr.append($('<td>').text(each['location']))
            tr.append($('<td>').text(each['action']))
            tr.append($('<td>').text(each['timestamp']))
            tr.append($('<td>').text(each['hostname'] || each['devicehostname']));
        }
        virusChart.setSelection(null);
    }else{
        console.log(virusChart.getSelection(),new Date(virusChart.getSelection()[0].date).yyyymmdd());
        console.log(virusData[new Date(virusChart.getSelection()[0].date).yyyymmdd()]);
        virusChart.setSelection(null);
    }
}
function loadData() {
    $.ajax({
        url: 'XMLFiles/MalwareReports_Bulk.xml',
        dataType: 'text',
        success: function (data) {
            data = parser(data);
            var newXML = document.createElement('div');
            newXML.innerHTML = data.documentElement.innerHTML;
            var chartData = [
            ];
            virusDataTable = new google.visualization.DataTable();
            virusDataTable.addColumn({ type: 'date', id: 'Date' });
            virusDataTable.addColumn({ type: 'number', id: 'Tickets' });
            for (var i = 0; each = data.documentElement.getElementsByTagName('MalwareReports')[i]; i++) {
                var date = new Date(each.getElementsByTagName('Timestamp')[0].innerHTML);
                if(date){
                    if (!virusData[date.yyyymmdd()]) {
                        virusData[date.yyyymmdd()] = [];
                    }
                    var obj = {};
                    $(each).children().each(function(i,e){
                        obj[e.tagName.toLowerCase()] = e.textContent;
                    });
                    virusData[date.yyyymmdd()].push(obj);
                    chartData.push([date,virusData[date.yyyymmdd()].length]);
                }
            }
            $.ajax({
                url: 'XMLFiles/SPYWare_Bulk.xml',
                dataType: 'text',
                success: function (data1) {
                    data1 = parser(data1);
                    var newXML = document.createElement('div');
                    newXML.innerHTML = data1.documentElement.innerHTML;
                    chartOptions.title = 'Virus Tickets';
                    virusDataTable = new google.visualization.DataTable();
                    virusDataTable.addColumn({ type: 'date', id: 'Date' });
                    virusDataTable.addColumn({ type: 'number', id: 'Tickets' });
                    chartData = [];
                    for (var i = 0; each = data1.documentElement.getElementsByTagName('SPYWare')[i]; i++) {
                        var date = new Date(each.getElementsByTagName('TIMESTAMP')[0].innerHTML);
                        if(date){
                            if (!virusData[date.yyyymmdd()]) {
                                virusData[date.yyyymmdd()] = [];
                            }
                            var obj = {};
                            $(each).children().each(function(i,e){
                                obj[e.tagName.toLowerCase()] = e.textContent;
                            });
                            virusData[date.yyyymmdd()].push(obj);
                            chartData.push([date,virusData[date.yyyymmdd()].length]);
                        }
                    }
                    virusDataTable.addRows(chartData);
                    virusChart = new google.visualization.Calendar(document.getElementById('chart1'));
                    google.visualization.events.addListener(virusChart, 'ready', virusReady);
                    document.getElementById('chart1').style.height = ($('.cont').width()/58 * 7 + 100) + 'px';
                    virusChart.draw(virusDataTable, chartOptions);
                }
            });

        },
        error: function () {
        }
    });
}
function closePop(){
    $('#table').fadeOut();
}

function drawChart() {
    $('#preloader').addClass('inactive').fadeOut();
    chartOptions = {
        title: "Calendar Chart",
        colorAxis :  {minValue: 0,  colors: ['#fc0','#f00']},
        legend : 'none',
        calendar: { cellSize: $('.cont').width()/58 }
        
    };
    $('.close').on('click',closePop);
    loadData();
}
/*
virus : 
MalwareReports_Bulk
SPYWare_Bulk
threat :
Vulnerabilty_Bulk
vpn : 
VPN_Bulk
hpsm :
HPSM_Tickets_Bulk
*/